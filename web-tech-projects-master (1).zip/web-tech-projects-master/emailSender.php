<?php

use PHPMailer\PHPMailer\PHPMailer;

require './vendor/autoload.php';
$mail = new PHPMailer();
$mail->IsSMTP();
$mail->SMTPDebug = 1;
$mail->SMTPAuth = true;
$mail->SMTPSecure = 'ssl';
$mail->Host = "smtp.gmail.com";
$mail->Port = 465;
$mail->IsHTML(true);
$mail->Username = "khaboofficial@gmail.com";
$mail->Password = "huehuehue";
$mail->SetFrom("no-reply@khabo.com","no-reply");
$mail->Subject = "magi";
$mail->Body = "shutki khao petni chodo";
//$mail->AddAddress("nihal.0.m7@gmail.com");
$mail->AddAddress("utsha.saha@yandex.com");

if (!$mail->Send()) {
    echo "Mailer Error: " . $mail->ErrorInfo;
} else {
    echo "Message has been sent";
}
