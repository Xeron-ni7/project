<?php
require './configs/userConfig.php';
if (isset($_GET['email']) && !empty($_GET['email']) AND isset($_GET['hash']) && !empty($_GET['hash'])) {
    // Verify data
    $email =mysqli_escape_string($conn,$_GET['email']);
    $hash = mysqli_escape_string($conn,$_GET['hash']);
    $search = mysqli_query($conn, "SELECT email, hash, active FROM users WHERE email='" . $email . "' AND hash='" . $hash . "' AND active='0'") or die(mysqli_error());
    if (mysqli_num_rows($search) > 0) {
        mysqli_query($conn, "UPDATE users SET active='1' WHERE email='" . $email . "' AND hash='" . $hash . "' AND active='0'") or die(mysqli_error());
        mysqli_query($conn, "delete from users WHERE email='" . $email . "' AND active='0'") or die(mysqli_error());
        header('location:index.php?verify=true');
    } else {
        echo 'Invalid Login';
    }
}
?>