<?php
require '../configs/userConfig.php';

use PHPMailer\PHPMailer\PHPMailer;

function sanitize($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

$username = sanitize($_POST['username']);
$password = sanitize($_POST['password']);
$hash = mysqli_escape_string($conn, md5(rand(0, 1000)));
$email = mysqli_escape_string($conn, filter_var(sanitize($_POST['email']), FILTER_SANITIZE_EMAIL));
$statement = "INSERT INTO `users`(`username`, `password`, `email`,`hash`) VALUES ('$username','$password','$email','$hash')";
$result = mysqli_query($conn, $statement);

if (!$result) {
    if ($conn->errno == 1062) {
        header('location:../register.php?username=1');
    } else {
        die("Query failed " . mysqli_error($conn));
    }
} else {

    require '../vendor/autoload.php';
    $mail = new PHPMailer();
    $mail->IsSMTP();
    $mail->SMTPDebug = 1;
    $mail->SMTPAuth = true;
    $mail->SMTPSecure = 'ssl';
    $mail->Host = "smtp.gmail.com";
    $mail->Port = 465;
    $mail->IsHTML(true);
    $mail->Username = "khaboofficial@gmail.com";
    $mail->Password = "huehuehue";
    $mail->SetFrom("no-reply@khabo.com", "no-reply");
    $mail->Subject = 'Signup | Verification| Welcome to Khabo!';
    $mail->Body = '

Hi ' . $username . ', thanks for signing up to khabo!<br>
Your account has been created, you can login with your credentials after you have activated your account by pressing the url below.<br>
------------------------<br>
Username: ' . $username . '<br>
Password: ' . $password . '<br>
------------------------<br>

Please click this link to activate your account:<br>
http://127.0.0.1/web-tech-projects/verify.php?email=' . $email . '&hash=' . $hash . '<br>
';
    $mail->AddAddress($email);

    if (!$mail->Send()) {
        echo "Mailer Error: " . $mail->ErrorInfo;
    } else {
        echo "Message has been sent";

        header('location:../index.php?reg=true');
    }
}