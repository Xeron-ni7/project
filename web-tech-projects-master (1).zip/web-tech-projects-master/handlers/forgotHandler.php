<?php
use PHPMailer\PHPMailer\PHPMailer;
require '../configs/userConfig.php';
function sanitize($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
$resethash = mysqli_escape_string($conn, md5(rand(0, 1000)));
$email = mysqli_escape_string($conn,filter_var(sanitize($_POST['email']), FILTER_SANITIZE_EMAIL));
$statement = "update `users` set `resethash`='$resethash' where `email`='$email'";
$result = mysqli_query($conn, $statement);
if (!$result) {
    die("Query failed " . mysqli_error($conn));
} else {

    require '../vendor/autoload.php';
    $mail = new PHPMailer();
    $mail->IsSMTP();
    $mail->SMTPDebug = 1;
    $mail->SMTPAuth = true;
    $mail->SMTPSecure = 'ssl';
    $mail->Host = "smtp.gmail.com";
    $mail->Port = 465;
    $mail->IsHTML(true);
    $mail->Username = "khaboofficial@gmail.com";
    $mail->Password = "huehuehue";
    $mail->SetFrom("no-reply@khabo.com", "no-reply");
    $mail->Subject = 'Khabo!-Reset Password';
    $mail->Body = '

Hi user, we have recieved a request to reset your password!<br>
If you have not requested to reset password, please ignore this mail.<br>
Click this link to continue:<br>
------------------------<br>
http://127.0.0.1/web-tech-projects/reset.php?email=' . $email . '&hash=' . $resethash . '<br>
------------------------<br>

-Khabo! 

';
    $mail->AddAddress($email);

    if (!$mail->Send()) {
        echo "Mailer Error: " . $mail->ErrorInfo;
    } else {
        echo "Message has been sent";

        header('location:../index.php?reset=1');
    }
}