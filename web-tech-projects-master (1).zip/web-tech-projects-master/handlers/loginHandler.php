<?php
require '../configs/userConfig.php';
function sanitize($data)
{
    $data=trim($data);
    $data=stripslashes($data);
    $data=htmlspecialchars($data);
    return $data;
}

$username = sanitize($_POST['username']);
$password = sanitize($_POST['password']);
$statement = "SELECT `username`, `password` FROM `users` WHERE `username`='$username' and `password`='$password' and `active`='1'";
$result = mysqli_query($conn, $statement);

if (mysqli_num_rows($result) > 0) {
    header('location:../success.php');
    /*setcookie('username', $username, time() + 86400);*/
    session_start();
    $_SESSION['userid'] = session_id();
    $_SESSION["username"] = $username;
} else {
    header('location:../index.php?login=1');
}

?>
